import java.util.Scanner;

/** This Program will ask the user to enter the width and length of 
a  rectangle,  and  then  display  the  area by calling multiple methods **/

public class RectangleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Scanner input = new Scanner(System.in);
		
		// Functions call
		double length = getLength();
		double width = getWidth();
		double area = getArea(length, width);
		displayData(length, width, area);
	}
	
	// displayData method to display the values of length, width, and area
	public static void displayData(double length, double width, double area) {
		// TODO Auto-generated method stub
		System.out.println("\nLength of rectangle is: " + length);
		System.out.println("Width of rectangle is: "+ width);
		System.out.println("Area of rectangle is: " + area);
	}
	
	// getArea method to calculate and display the area
	public static double getArea(double length, double width) {
		// TODO Auto-generated method stub
		double area = length*width;
		return area;
	}
	
	// getWidth method to return width value
	public static double getWidth() {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("\nEnter the width");
		double width = input.nextDouble();
		return width;
	}
	
	// getLength method to return length value
	public static double getLength() {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the length");
		double length = input.nextDouble();
		return length;
	}

	

}
