import java.util.Scanner;

/** This program validates a password input by the user using the rules: 
a.	The password must be at least 8 characters long 
b.	The password must have at least one uppercase and one lowercase letter 
c.	The password must have at least one digit 
 **/
public class ValidPassword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a password: ");
		String pwd = input.next();
		System.out.println("Conferm Password: ");
		String cnfrm = input.next();

		// calling isValid method using if condition
		if(isValid(pwd, cnfrm)) {
			System.out.println("Password is valid");
		} else {
			System.out.println("Password is not valid");
			System.out.println("Your password must contain: "
					+ "\n(1): At least 8 characters"
					+ "\n(2): At least one upercase and one lowercase letter "
					+ "\n(3): At least one digit");
		}
	}

	// This methods check if entered password (pwd) is valid or not
	private static boolean isValid(String pwd, String cnfrm) {
		// TODO Auto-generated method stub

		// To see if password confirmation is matched
		if(!(pwd.equals(cnfrm))) {
			System.out.println("Password did not match");
			return false;
		}

		// To see if the length is valid
		if(!(pwd.length() >= 8)) {
			return false;
		}

		if (true) {
			int count = 0;

			// check digits from 0 to 9
			for (int i = 0; i <= 9; i++) {

				// to convert int to string
				String str1 = Integer.toString(i);

				if (pwd.contains(str1)) {
					count = 1;
				}
			}
			if (count == 0) {
				return false;
			}
		}

		if (true) {
			int count = 0;

			// To check capital letters
			for (int i = 65; i <= 90; i++) {

				// type casting
				char c = (char)i;

				String str1 = Character.toString(c);
				if (pwd.contains(str1)) {
					count = 1;
				}
			}
			if (count == 0) {
				return false;
			}
		}

		if (true) {
			int count = 0;

			// checking small letters
			for (int i = 97; i <= 122; i++) {

				// type casting
				char c = (char)i;
				String str1 = Character.toString(c);

				if (pwd.contains(str1)) {
					count = 1;
				}
			}
			if (count == 0) {
				return false;
			}
		}

		// if all false conditions fails
		return true;
	}

}


