import java.util.Scanner;

/** This program counts and return all the vowels in a string **/
public class CountVowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = input.next();

		// calling vowel function
		vowels(str);
	}

	// vowel method to count vowel characters in a string
	private static int vowels(String str) {
		int count = 0;

		// for loop to go through each character of string
		for(int i = 0; i < str.length(); i++) {
			// if statement to see if character matches 
			//			any vowels characters
			if(str.charAt(i)== 'a' || str.charAt(i)== 'e' 
					|| str.charAt(i)== 'i' || str.charAt(i)== 'o' 
					|| str.charAt(i)== 'u' )
				count++;
		}
		System.out.println("Number of vowels in the entered string are: " 
		+ count);
		return count;

	} // vowels method ends

}
