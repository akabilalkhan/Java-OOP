import java.util.Scanner;
/** This program asks the user to enter five test scores and
 *  display a letter grade for each score and the average test score
 *  and the grade associated with the average score **/

public class TestScore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		// Getting user inputs
		System.out.print("Enter score one: ");
		int scoreOne = input.nextInt();
		System.out.print("Enter score two: ");
		int scoreTwo = input.nextInt();
		System.out.print("Enter score three: ");
		int scoreThree = input.nextInt();
		System.out.print("Enter score four: ");
		int scoreFour = input.nextInt();
		System.out.print("Enter score five: ");
		int scoreFive = input.nextInt();
		
		System.out.println("\nScores         Letter Grade");
		System.out.print("  " +scoreOne + "                  ");
		determineGrade(scoreOne);
		System.out.print("  " +scoreTwo + "                  ");
		determineGrade(scoreTwo);
		System.out.print("  " +scoreThree + "                  ");
		determineGrade(scoreThree);
		System.out.print("  " +scoreFour + "                  ");
		determineGrade(scoreFour);
		System.out.print("  " +scoreFive + "                  ");
		determineGrade(scoreFive);
		
		// calling functions
		System.out.print("Average score is: ");
		int grade = calcAverage(scoreOne, scoreTwo, scoreThree, scoreFour, scoreFive);
		System.out.print("\nGrade: ");
		determineGrade(grade);
	}
	
	// calcAverage method to calculate average of the scores
	public static int calcAverage(int s1, int s2, int s3, int s4, int s5) {
		int avg = (s1+s2+s3+s4+s5)/5;
		System.out.print(avg);
		return avg;
	}
	
	// determineGrade method to determine grades of given score
	public static void determineGrade(int avgScore) {
		if(avgScore >=90 && avgScore <=100) {
			System.out.println("A");
		} else if(avgScore>=80 && avgScore < 90) {
			System.out.println("B");
		} else if(avgScore >=70 && avgScore < 80) {
			System.out.println("C");
		} else if (avgScore >= 60 && avgScore <70) {
			System.out.println("D");
		} else
			System.out.println("F");
	}
}
