import java.text.DecimalFormat;
import java.util.Scanner;

/**This program is for converting a temperature from Farenheit to Celsius: 
C  =  5/9  (F-32)  where  F  is the  Farenheit temperature as an argument. 
And C is the Celsius temperature.  **/

public class FarenheitToCelsius {

	public static void main(String[] args)
	{

		// Calling DecimalFormat class for decimals
		DecimalFormat df = new DecimalFormat("0.0");

		// Print Statements for the header of the table
		System.out.println("Fahrenheit        Celsius");

		// Loop to convert and display temperatures by calling celsius method
		for (double i = 0; i <= 20; i++) {
			System.out.println( df.format(i) + "                 " + df.format(celsius(i)) );
		}

	}

	
	// celsius Method that takes a farenheit temperature as an argument,
	//	 convert it ino celsius
	public static double celsius(double f)
	{
		double c = 5.0 / 9.0 * (f - 32);
		return c;
	}

} 