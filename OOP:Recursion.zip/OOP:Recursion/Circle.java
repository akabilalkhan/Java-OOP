import java.util.Scanner;

/** This program ask user for inputing the radius of a circle
 *  and provide the user with the choices to print either getting area, 
 *  circumference or diameter of the circle **/
public class Circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Scanner class
		Scanner input = new Scanner(System.in);

		// Prompt user for inputting the radius
		System.out.print("Enter the radius of a circle: ");
		double radius = input.nextDouble();
		
		// Prompting user to input a char value
		System.out.println("(1) Enter A or a to calculate area of the circle"
				+ "\n(2) Enter C or c to calculate circumference of the circle"
				+ "\n(3) Enter D or d to calculate diameter of circle");
		char ans = input.next().charAt(0);
		
		// Switch statements
		switch (ans) {
		case 'a':
			System.out.printf("Area of the circle is: %.2f" , Math.PI*radius*radius);
			break;
		case 'A':
			System.out.printf("Area of the circle is: %.2f" , Math.PI*radius*radius);
			break;
		case 'c':
			System.out.printf("Circumference of the circle is: %.2f" , 2*Math.PI*radius);
			break;
		case 'C':
			System.out.printf("Circumference of the circle is: %.2f" , 2*Math.PI*radius);
			break;
		case 'd':
			System.out.printf("Diameter of the circle is: %.2f" , 2*radius);
			break;
		case 'D':
			System.out.printf("Diameter of the circle is: %.2f" , 2*radius);
			break;
		default:
			System.out.println("Please enter a valid value");
			break;

		}
	}

}
