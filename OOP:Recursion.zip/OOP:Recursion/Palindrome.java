import java.util.Scanner;

/** This program checks if a string is a palindrome or not**/
public class Palindrome {

	public static void main (String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string to see of it's Palindrome");
		String str = input.next();

		// condition for the method to return true or false
		if (isPalindrome(str)) {
			System.out.println("String is a Palindrome");
		}
		else {
			System.out.println("String is not a Palindrome");
		}
	} // main ends

	// isPalindrome method to see if a string is palindrome
	public static boolean isPalindrome(String str)
	{

		// if condition to see the length 
		if(str.length() == 0 || str.length() == 1)
			return true; 

		// check for the first and last characters
		if(str.charAt(0) == str.charAt(str.length()-1))
			return isPalindrome(str.substring(1, str.length()-1)); // recursive call

		// if its not the case than string is not.
		return false;

	}// isPalindrome method ends
}
