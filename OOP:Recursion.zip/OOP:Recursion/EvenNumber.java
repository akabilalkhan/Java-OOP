import java.util.Scanner;

/** This program use a method isEven() which takes an integer as an 
 * argument and returns true if the argument is even, or false otherwise.**/
public class EvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);

		// prompting user for input
		System.out.print("Enter a number to see if it is an even number: ");
		int num = input.nextInt();

		// calling isEven method
		isEven(num);
	}

	// isEven method to check if a number is even or not
	private static void isEven(int num) {

		// if-else condition
		if(num%2 == 0) {
			System.out.println(num + " is an even number");
		} else 
			System.out.println(num + " is not an even number" );

	}

}
