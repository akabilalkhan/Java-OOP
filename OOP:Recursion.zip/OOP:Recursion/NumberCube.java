import java.util.Scanner;

/** This program asks the user to enter two numbers one of type 
integer  and  another  of  type  double to calculate the square of 
each number and also calculate the cube of each number**/
public class NumberCube {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		// Asking user to input two numbers
		System.out.print("Enter a number of type 'int': ");
		int intNum = input.nextInt();
		System.out.print("Enter a number of type 'double': ");
		double doubleNum = input.nextDouble();
		
		// Calling each method
		getSquare(intNum); 
		getSquare(doubleNum);
		getCube(intNum);
		getCube(doubleNum);
		

	}
	// getSquare methods with different parameter types
	public static void getSquare(int num) {
		System.out.println("\nSquare of integer is: " + num * num);
	}
	public static void getSquare(double num) {
		System.out.printf("Square of double is: %.2f" , num * num);
	}
	
	// getCube methods with different parameter types
	public static void getCube(int num) {
		System.out.println("\n\nCube of integer is: " + num * num * num);
	}
	public static void getCube(double num) {
		System.out.printf("Cube of double is: %.2f" , num * num * num);
	}

}