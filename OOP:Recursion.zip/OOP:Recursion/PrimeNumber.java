import java.util.Scanner;

/** This program prints first fifty prime numbers **/
public class PrimeNumber {

	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("How many prime numbers you want to print? ");
		int num = input.nextInt();
		int count = 0;

		if(isPrime(num)) {
			count++;
			System.out.print(num + " ");
			if(count == 10) {
				System.out.println();
			}
			count =  0;
		}
	}

	static boolean isPrime(int num){
		int count = 0;
		for (int i = 1; i <= num; i++) {
			count = 0;
			for (int j = 2; j <= i / 2; j++) {
				if (i % j == 0) {
					count++;
					break;
				}
			}

			if (count == 0) {
				System.out.print(i);
			}

		}
		return true;

	}
}


