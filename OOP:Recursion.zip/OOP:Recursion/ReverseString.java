import java.util.Scanner;

/**This program return a reverse of the entered string**/
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = input.next();

		reverse(str); // calling reverse method
	}

	// Method to reverse the string
	public static String reverse(String str) {

		// to see if only one character or none else reverse the string
		if ((str==null)||(str.length() <= 1))
			System.out.println(str);
		else
		{
			System.out.print(str.charAt(str.length()-1));
			reverse(str.substring(0,str.length()-1));
		}
		return str;

	}

}
