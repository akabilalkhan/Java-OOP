import java.util.Scanner;

/** This program which takes a string and a character as arguments 
 * and returns the number of occurrences of that character in the 
 * string as an integer. **/
public class Occurences {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = input.next();
		System.out.print("\nEnter a character: ");
		char chr = input.next().charAt(0);

		// calling getOccurences function
		getOccurences(str, chr);
	}

	// getOccurences method to count characters
	private static int getOccurences(String str, char chr) {
		int count = 0;

		// for loop to go through each character of string
		for(int i = 0; i < str.length(); i++) {
			// if statement to see if character matches any string characters
			if(str.charAt(i)== chr)
				count++;
		}
		System.out.println(chr + " is occured " + count + " times in String " + str);
		return count;

	} // getOccurence method ends

}
