import java.util.Scanner;

/** This program use a method CountWords() 
 * that returns the count of all words in the string **/
public class WordsCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = input.nextLine();

		System.out.println("Number of String are " + countWords(str));
	}

	// countWords method to count all the words in a string 
	public static int countWords(String str)
	{
		int count = 0;
		// condition for the spaces
		if (!(" ".equals(str.substring(0, 1))) 
				|| !(" ".equals(str.substring(str.length() - 1)))) {
			// to go through each character
			for (int i = 0; i < str.length(); i++)
			{
				// to analyze a space
				if (str.charAt(i) == ' ')
				{
					count++;
				}
			}
			count = count + 1; 
		}
		return count; // returns 0 if string starts or ends with space " ".
	}
}